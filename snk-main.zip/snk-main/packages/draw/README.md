# @snk/draw

Draw grids and snakes on a canvas.
