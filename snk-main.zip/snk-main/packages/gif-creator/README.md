# @snk/gif-creator

Generate a gif file from the grid and snake path.

Relies on graphics magic and gifsicle binaries.
