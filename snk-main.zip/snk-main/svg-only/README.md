# svg-only

Another action running purely on js (without Docker).

As a drawback, it can not generate gif image.

## Build process

dist file are built and push on release, by the release action.
